package gov.epa.hwir.util;

import java.io.*;

public class PercentileDistribution extends Distribution
{
  double percents[];
  public void writeHeader1(PrintStream ps)
  {
    for (int i=0;i<percents.length;i++)
    {
      if (i>0) ps.print(',');
      ps.print('"');
      ps.print(longName);
      ps.print(percents[i]);
      ps.print('"');
    }
  }
  public void writeHeader2(PrintStream ps)
  {
    for (int i=0;i<percents.length;i++)
    {
      if (i>0) ps.print(',');
      ps.print('"');
      ps.print(shortName);
      ps.print(percents[i]);
      ps.print('"');
    }
  }
  public void writeValue(PrintStream ps)
  {
    // sort vector values
    int idx;
    for (int i=0;i<percents.length;i++)
    {
      if (i>0) ps.print(',');
      idx=(int)percents[i]*values.size()/100.0;
      ps.print(values.elementAt(idx));
    }
  }
  public void setPercentiles(double newPercents[])
  {
    percents=newPercents();
  }
}
