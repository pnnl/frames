package gov.epa.hwir.util;

import java.io.*;
import GNUPlot.Chart;

public class TestPlots {
  String ssfPath,grfPath,path;
  String hd;
  String CASID;
  String ChemName;
  boolean ChemEco,ChemHuman;
  String Site;
  String Source;
  hwirio io;
  public void setPaths(String newSSFPath,String newGRFPath)
  {
    ssfPath=newSSFPath;
    grfPath=newGRFPath;
  }
  public void setHeaderFile(String newHeaderFile)
  {
    hd=newHeaderFile;
  }
  private void setArgs()
  {
    StringBuffer sb=new StringBuffer();
    sb.append("time date ");
    sb.append(ssfPath);
    sb.append(" ");
    sb.append(grfPath);
    sb.append(" 1 hdPlots.grf");
    System.out.println(sb.toString());
    io.setArgs(sb.toString());
  }
  public void setOutputPath(String newPath)
  {
    path=newPath;
  }
  public TestPlots()
  {
    io=new hwirio();
  }
  public void generate()
  {
// Get Site Layout file name from header
//"Source",0,"STRING",0,"",
//"LF",
//"SiteId",0,"STRING",0,"",
//"1630106",
    StringBuffer sl=new StringBuffer();
    setArgs();
    io.openGroups();
    try
    {
      io.addRWGroup(hd);
      io.addRWGroup("cpsr.ssf");
      ChemName=io.readString("cpsr.ssf","ChemName","",1);
      ChemEco=io.readLog("cpsr.ssf","ChemEco","");
      ChemHuman=io.readLog("cpsr.ssf","ChemHuman","");
      io.removeGroup("cpsr.ssf");
      PrintStream html=new PrintStream(new FileOutputStream(path+"index.html"));
      html.println("<HEAD></HEAD>");
      html.println("<BODY>");
      Source=io.readString(hd,"Source","");
      Site=io.readString(hd,"SiteId","");
      CASID=io.readString(hd,"CASID","");
      html.println("<Center><font size=+1><b>"+ChemName+"("+CASID+") at "+Site+" in a(an) "+Source+"</B></Font></Center>");
      sl.append("sl");
      sl.append(Source.substring(0,2));
      sl.append(Site);
      sl.append(".ssf");

      SourcePlots sp=new SourcePlots(sl.toString());
      sp.write(html);
      AirPlots ap=new AirPlots(sl.toString());
      ap.write(html);
      WatershedPlots wp=new WatershedPlots(sl.toString());
      wp.write(html);
      if (!Source.equalsIgnoreCase("AT"))
      {
        VadPlots vp=new VadPlots(sl.toString());
        vp.write(html);
        AquiferPlots aqp=new AquiferPlots(sl.toString());
        aqp.write(html);
      }

      SWPlots swp=new SWPlots(sl.toString());
      swp.write(html);
      AFPlots afp=new AFPlots(sl.toString());
      afp.write(html);
      if (ChemEco)
      {
        TFPlots tfp=new TFPlots(sl.toString());
        tfp.write(html);
        EEPlots eep=new EEPlots(sl.toString());
        eep.write(html);
      }
      if (ChemHuman)
      {
        FFPlots ffp=new FFPlots(sl.toString());
        ffp.write(html);
        HEPlots hep=new HEPlots(sl.toString());
        hep.write(html);
      }
      html.println("</BODY>");
      html.close();
    }
    catch(FileNotFoundException e)
    {
    }
    io.closeGroups();
  }
  public static void main(String args[])
  {
    TestPlots tp=new TestPlots();
    tp.setPaths(args[0]+"ssf",args[0]+"grf");
    tp.setHeaderFile(args[1]);
    tp.setOutputPath(args[2]);
    if (args.length>=4)
      Chart.setPaths(args[0],args[3]);
    tp.generate();
  }
}