package gov.epa.hwir.util;

public interface ProcessListener
{
  public void outputString(String line);
} 