package gov.epa.hwir.util;

import java.io.*;
import GNUPlot.Chart;
import GNUPlot.Series;

public class WatershedPlots extends Plots {
  String sl,ws;
  hwirio io;
  public WatershedPlots(String newSiteLayoutFile)
  {
    sl=newSiteLayoutFile;
    ws="ws.grf";
    io=new hwirio();
  }

  private void addChart(String title,String units,String variable)
  {
    String varny=variable+"NY";
    String varyr=variable+"YR";
    boolean atLeastOne=false;
    Chart c=new Chart();
    c.setTitle(title);
    c.setLabels("year",units);
    int num=io.readInt(sl,"NumWSSub","");
    for (int j=0;j<num;j++)
    {
      Series y=new Series();
      Series x=new Series();
      int n=io.readInt(ws,varny,"",j+1);
      for (int i=0;i<n;i++)
      {
        atLeastOne=true;
        x.add((double)io.readInt(ws,varyr,"year",j+1,i+1));
        y.add(io.readReal(ws,variable,units,j+1,i+1));
      }
      y.setLabel(variable+"("+(j+1)+")");
      if (n>0)
      {
        c.addSeries(y);
        c.addXSeries(x);
      }
    }
//    c.setXSeries(x);
    if (atLeastOne) addPlot(c);
  }

  private void addNYRMetChart(String title,String units,String variable)
  {
    String varny=variable+"NY";
    String varyr=variable+"YR";
    Chart c=new Chart();
    c.setTitle(title);
    c.setLabels("year",units);
    Series x=new Series();
    int n=io.readInt(ws,"NyrMet","year");
    for (int i=0;i<n;i++)
      x.add((double)i+1);
    int num=io.readInt(sl,"NumWSSub","");
    for (int j=0;j<num;j++)
    {
      Series y=new Series();
      for (int i=0;i<n;i++)
        y.add(io.readReal(ws,variable,units,j+1,i+1));
      y.setLabel(variable+"("+(j+1)+")");
      c.addSeries(y);
      c.addXSeries(x);
    }
//    c.setXSeries(x);
    addPlot(c);
  }

//BFann,1,float,0,1.00E+08,m3/d,long-term avg baseflow to waterbody ,NumWSSub,,,,
  public void write(PrintStream ps)
  {
    int n;
    io.addRWGroup(sl);
    io.addRWGroup(ws);
    setCaption("WaterShed");
    addChart("Depth avg. Soil Conc.","ug/g","CTdaR");
    addChart("Surf. Soil Conc.","ug/g","CTssR");
    addChart("Chemical load to SW","g/d","SWLoadChemR");
    addNYRMetChart("Annual avg. recharge","m/d","AnnInfil");
    addNYRMetChart("Runoff flow to SW","m3/d","RunoffR");
    addNYRMetChart("Total Suspended Solids","g/d","SWLoadSolidR");
    io.removeGroup(ws);
    io.removeGroup(sl);
    super.write(ps);
  }
}
