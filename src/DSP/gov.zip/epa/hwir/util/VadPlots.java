package gov.epa.hwir.util;

import java.io.*;
import GNUPlot.Series;
import GNUPlot.Chart;

public class VadPlots extends Plots {
  String sl,vz,cp;
  hwirio io;
  public VadPlots(String newSL)
  {
    sl=newSL;
    cp="cpvz.ssf";
    io=new hwirio();
  }
  private void addCWTChart()
  {
    Chart c=new Chart();
    c.setTitle("Conc. at Water Table ");
    c.setLabels("year","mg/L");
    String varny="NTS";
    String varyr="TWT";
    if (io.readReal(vz,"TSourc","yr")<1.0) return;
    int n=io.readInt(vz,varny,"yr");
    int nc=io.readInt(cp,"NumChem","");
    int j=0;
//    for (int j=0;j<nc;j++)
//    {
      Series x=new Series();
      Series y=new Series();
      for (int i=0;i<n;i++)
      {
        x.add(io.readReal(vz,varyr,"yr",i+1));
        y.add(io.readReal(vz,"CWT","mg/L",i+1,1));
      }
      y.setLabel("CWT "+io.readString(cp,"ChemName","",j+1));
      c.addSeries(y);
      c.addXSeries(x);
//    }
    if (n>=2) addPlot(c);
  }

  public void write(PrintStream ps)
  {
    int n;
    io.addRWGroup(sl);
    vz="vz"+io.readString(sl,"VadID","",1)+".grf";
    io.addRWGroup(vz);
    io.addRWGroup(cp);
    setCaption("Vadose Zone");
    addCWTChart();
    io.removeGroup(cp);
    io.removeGroup(vz);
    io.removeGroup(sl);
    super.write(ps);
  }

}