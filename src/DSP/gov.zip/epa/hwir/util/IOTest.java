package gov.epa.hwir.util;

public class IOTest {

  public IOTest() {
  }
  static void main(String args[])
  {
    hwirio hio=new hwirio();
    hio.setArgs("65536 256 d:\\mims\\mimsfw\\gov\\epa\\hwir\\ssf  d:\\mims\\mimsfw\\gov\\epa\\hwir\\grf 1 hdprod.ssf hdtest.grf");
    System.out.println("Before OpenGroups");
    hio.openGroups();
    System.out.println("After OpenGroups");
    System.out.println("NumArgs[7]:"+hio.numArgs());
    System.out.println("GetArgInt(1)[65536]:"+hio.getArgInt(1));
    System.out.println("GetArgInt(2)[256]:"+hio.getArgInt(2));
    System.out.println("GetArgString(7)[hdtest.grf]:"+hio.getArgString(7));
    System.out.println("Warning \"this is a test\"");
    hio.warning("This is a test");
    System.out.println("ReadInt(\"hdprod.ssf\",\"ChemCnt\",\"\")[1]:"+hio.readInt("hdprod.ssf","ChemCnt",""));
    System.out.println("ReadInt(\"hdprod.ssf\",\"SiteCnt\",\"\")[201]:"+hio.readInt("hdprod.ssf","SiteCnt",""));

    System.out.println("WriteInt(\"hdtest.grf\",\"Int0\",\"1/hr\",1)[1 in hdtest.grf]:");
    hio.writeInt("hdtest.grf","Int0","1/hr",1);
    System.out.print("ReadInt(\"hdtest.grf\",\"Int0\",\"1/hr\")[1]:");
    System.out.println(hio.readInt("hdtest.grf","Int0","1/hr"));

    System.out.println("WriteReal(\"hdtest.grf\",\"Real1\",\"2/day\",1,9.0)[9.0 in hdtest.grf]:");
    hio.writeReal("hdtest.grf","Real1","2/day",1,9.0);
    System.out.print("ReadReal(\"hdtest.grf\",\"Real1\",\"2/day\",1)[9.0]:");
    System.out.println(hio.readReal("hdtest.grf","Real1","2/day",1));

    System.out.println("WriteLog(\"hdtest.grf\",\"Log2\",\"\",1,1,true)[\"T\" in hdtest.grf]:");
    hio.writeLog("hdtest.grf","Log2","",1,1,true);
    System.out.print("ReadLog(\"hdtest.grf\",\"Log2\",\"\",1,1)[T]:");
    System.out.println(hio.readLog("hdtest.grf","Log2","",1,1));

    System.out.println("WriteString(\"hdtest.grf\",\"String3\",\"\",1,1,1,\"Test\")[Test in hdtest.grf]:");
    hio.writeString("hdtest.grf","String3","",1,1,1,"Test");
    System.out.print("ReadString(\"hdtest.grf\",\"String3\",\"\",1,1,1)[Test]:");
    System.out.println(hio.readString("hdtest.grf","String3","",1,1,1));
//    hio.error("This is an error");
//    System.out.println("Should not see this message");
    hio.closeGroups();
    System.out.println("Closed Groups successfully");
  }
}