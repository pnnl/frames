package gov.epa.hwir.util;

import java.io.*;
import GNUPlot.Chart;
import GNUPlot.Series;

public class TFPlots extends Plots {

  String sl,af;
  hwirio io;
  public TFPlots(String newSiteLayout) {
    sl=newSiteLayout;
    af="tf.grf";
    io=new hwirio();
  }
  private void add3DChart(String title,String variable,String units)
  {
    Chart c=new Chart();
    boolean atLeastOne=false;
    c.setTitle(title);
    c.setLabels("year",units);
    String varny=variable+"NY";
    String varyr=variable+"YR";
    int numwbn=io.readInt(sl,"NumHab","unitless");
    for (int k=0;k<numwbn;k++)
    {
      int nrch=io.readInt(sl,"HabNumRange","unitless",k+1);
      for (int j=0;j<nrch;j++)
      {
        int n=io.readInt(af,varny,"",k+1,j+1);
        Series y=new Series();
        Series x=new Series();
        for (int i=0;i<n;i++)
        {
          atLeastOne=true;
          x.add(io.readInt(af,varyr,"year",k+1,j+1,i+1));
          y.add(io.readReal(af,variable,units,k+1,j+1,i+1));
        }
        y.setLabel(variable+" ("+(k+1)+","+(j+1)+")");
        if (n>=2)
        {
          c.addSeries(y);
          c.addXSeries(x);
        }
      }
    }
    if (atLeastOne) addPlot(c);
  }

  private void add2DChart(String title,String variable,String units)
  {
    Chart c=new Chart();
    boolean atLeastOne=false;
    c.setTitle(title);
    c.setLabels("year",units);
    String varny=variable+"NY";
    String varyr=variable+"YR";
    int numwbn=io.readInt(sl,"NumHab","unitless");
    for (int k=0;k<numwbn;k++)
    {
      int n=io.readInt(af,varny,"",k+1);
      Series x=new Series();
      Series y=new Series();
      for (int i=0;i<n;i++)
      {
        atLeastOne=true;
        x.add(io.readInt(af,varyr,"year",k+1,i+1));
        y.add(io.readReal(af,variable,units,k+1,i+1));
      }
      y.setLabel(variable+" ("+(k+1)+")");
      if (n>=2)
      {
        c.addSeries(y);
        c.addXSeries(x);
      }
    }
    if (atLeastOne) addPlot(c);
  }

  public void write(PrintStream ps)
  {
    int n;
    setCaption("Terrestrial Foodweb");
    io.addRWGroup(sl);
    io.addRWGroup(af);
//Cbirds_sm_max,2,Float,0,10000000,mg/kg WW, NumHab,CBirds_sm_maxNy
//Cbirds_sm_maxNY,1,Integer,0,10000000,      NumHab
//Cbirds_sm_maxYR,2,Integer,0,10000000,Year, NumHab,CBirds_Sm_maxNY
//Cbirds_sm_min,2,Float,0,10000000,mg/kg WW
//Cbirds_sm_minNY,1,Integer,0,10000000,
//Cbirds_sm_minYR,2,Integer,0,10000000,Year
    add2DChart("C Small Birds Max","Cbirds_sm_max","mg/kg WW");
    add2DChart("C Small Birds Min","Cbirds_sm_min","mg/kg WW");
//Cherbiverts_max,2,Float,0,10000000,mg/kg WW
//Cherbiverts_maxNY,1,Integer,0,10000000,
//Cherbiverts_maxYR,2,Integer,0,10000000,Year
//Cherbiverts_min,2,Float,0,10000000,mg/kg WW
//Cherbiverts_minNY,1,Integer,0,10000000,
//Cherbiverts_minYR,2,Integer,0,10000000,Year
    add2DChart("C Small Herbivert Max","Cherbiverts_max","mg/kg WW");
    add2DChart("C Small Herbivert Min","Cherbiverts_min","mg/kg WW");
//CHerp_sm_max,2, Float,0,1.00E+06, mg/kg WW
//CHerp_sm_maxNY,1, Integer,0,1.00E+06,
//CHerp_sm_maxYR,2, Integer,0,1.00E+06, Year
//CHerp_sm_min,2, Float,0,1.00E+06, mg/kg WW
//CHerp_sm_minNY,1, Integer,0,1.00E+06,
//CHerp_sm_minYR,2, Integer,0,1.00E+06, Year
    add2DChart("C Small Herp Max","CHerp_sm_max","mg/kg WW");
    add2DChart("C Small Herp Min","CHerp_sm_min","mg/kg WW");
//Cmammals_sm_max,2,Float,0,10000000,mg/kg WW
//Cmammals_sm_maxNY,1,Integer,0,10000000,
//Cmammals_sm_maxYR,2,Integer,0,10000000,Year
//Cmammals_sm_min,2,Float,0,10000000,mg/kg WW
//Cmammals_sm_minNY,1,Integer,0,10000000,
//Cmammals_sm_minYR,2,Integer,0,10000000,Year
    add2DChart("C Small Mammals Max","Cmammals_sm_max","mg/kg WW");
    add2DChart("C Small Mammals Min","Cmammals_sm_min","mg/kg WW");
//Comniverts_max,2,Float,0,10000000,mg/kg WW
//Comniverts_maxNY,1,Integer,0,10000000,
//Comniverts_maxYR,2,Integer,0,10000000,Year
//Comniverts_min,2,Float,0,10000000,mg/kg WW
//Comniverts_minNY,1,Integer,0,10000000,
//Comniverts_minYR,2,Integer,0,10000000,Year
    add2DChart("C Omniverts Max","Comniverts_max","mg/kg WW");
    add2DChart("C Omniverts Min","Comniverts_min","mg/kg WW");
//CTdaAveHabRange,3,Float,0,10000000,ug/g
//CTdaAveHabRangeNY,2,Integer,0,10000000,
//CTdaAveHabRangeYR,3,Integer,0,10000000, Year
    add3DChart("C Tda Ave","CTdaAveHabRange","ug/g");
//CTssAveHabRange,3,Float,0,10000000,ug/g
//CTssAveHabRangeNY,2,Integer,0,10000000,
//CTssAveHabRangeYR,3,Integer,0,10000000, Year
    add3DChart("C TSS Ave","CTssAveHabRange","ug/g");
//Cinvert_HabRange,3,Float,0,10000000,mg/kg WW,NumHab,HabNumRange,Cinvert_HabRange
//Cinvert_HabRangeNY,2,Integer,0,10000000,
//Cinvert_HabRangeYR,3,Integer,0,10000000,Year
    add3DChart("C invert","Cinvert_HabRange","mg/kg WW");
//Cworms_HabRange,3,Float,0,10000000,mg/kg WW
//Cworms_HabRangeNY,2,Integer,0,10000000,
//Cworms_HabRangeYR,3,Integer,0,10000000,Year
    add3DChart("C Worms","Cworms_HabRange","mg/kg WW");
//Pexfruit_HabRange,3,Float,0,10000000,mg/kg WW
//Pexfruit_HabRangeNY,2,Integer,0,10000000,
//Pexfruit_HabRangeYR,3,Integer,0,10000000,Year
    add3DChart("P Ex Fruit.","Pexfruit_HabRange","mg/kg WW");
//Pexveg_HabRange,3,Float,0,10000000,mg/kg WW
//Pexveg_HabRangeNY,2,Integer,0,10000000,
//Pexveg_HabRangeYR,3,Integer,0,10000000,Year
    add3DChart("P Ex Veg.","Pexveg_HabRange","mg/kg WW");
//Pforage_HabRange,3,Float,0,10000000,mg/kg WW
//Pforage_HabRangeNY,2,Integer,0,10000000,
//Pforage_HabRangeYR,3,Integer,0,10000000,Year
    add3DChart("P Forage","Pforage_HabRange","mg/kg WW");
//Pgrain_HabRange,3,Float,0,10000000,mg/kg WW
//Pgrain_HabRangeNY,2,Integer,0,10000000,
//Pgrain_HabRangeYR,3,Integer,0,10000000,Year
    add3DChart("P Grain","Pgrain_HabRange","mg/kg WW");
//Proot_HabRange,3,Float,0,10000000,mg/kg WW
//Proot_HabRangeNY,2,Integer,0,10000000,
//Proot_HabRangeYR,3,Integer,0,10000000,Year
    add3DChart("P Root","Proot_HabRange","mg/kg WW");
//Psilage_HabRange,3,Float,0,10000000,mg/kg WW
//Psilage_HabRangeNY,2,Integer,0,10000000,
//Psilage_HabRangeYR,3,Integer,0,10000000,Year
    add3DChart("P Silage","Psilage_HabRange","mg/kg WW");
    io.removeGroup(af);
    io.removeGroup(sl);
    super.write(ps);
  }
}
