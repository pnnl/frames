package gov.epa.hwir.util;

import java.io.*;
import GNUPlot.Chart;
import GNUPlot.Series;


public class AFPlots extends Plots {
  String sl,af;
  hwirio io;
  public AFPlots(String newSiteLayout) {
    sl=newSiteLayout;
    af="af.grf";
    io=new hwirio();
  }
  private void addChart(String title,String variable,String units)
  {
    Chart c=new Chart();
    boolean atLeastOne=false;
    c.setTitle(title);
    c.setLabels("year",units);
    String varny=variable+"NY";
    String varyr=variable+"YR";
    int numwbn=io.readInt(sl,"NumWBN","");
    for (int k=0;k<numwbn;k++)
    {
      int nrch=io.readInt(sl,"WBNNumFishableRch","unitless",k+1);
      for (int j=0;j<nrch;j++)
      {
        int idx=io.readInt(sl,"WBNFishableRchIndex","unitless",k+1,j+1);
        int n=io.readInt(af,varny,"",k+1,idx);
        Series x=new Series();
        Series y=new Series();
        for (int i=0;i<n;i++)
        {
          atLeastOne=true;
          x.add(io.readInt(af,varyr,"year",k+1,idx,i+1));
          y.add(io.readReal(af,variable,units,k+1,idx,i+1));
        }
        y.setLabel(variable+" ("+(k+1)+","+(idx)+")");
        if (n>=2)
        {
          c.addSeries(y);
          c.addXSeries(x);
        }
      }
    }
//    c.setXSeries(x);
    if (atLeastOne) addPlot(c);
  }

//Caqmp,3,FLOAT,0,1000000,mg/kg WW,,NumWBN,WBNNumRch,CaqmpNY
//CaqmpNY,2,INTEGER,0,10000,,,NumWBN,WBNNumRch,
//CaqmpYR,3,INTEGER,0,10000,year,,NumWBN,WBNNumRch,CaqmpNY

//Cbenthff,3,FLOAT,0,1000000,unitless,,NumWBN,WBNNumRch,CbenthffNY
//CbenthffNY,2,INTEGER,0,10000,,,NumWBN,WBNNumRch,
//CbenthffYR,3,INTEGER,0,10000,year,,NumWBN,WBNNumRch,CbenthffNY

//CT3Filet,3,FLOAT,0,1000000,mg/kg WW,,NumWBN,WBNNumRch,CT3FiletNY
//CT3FiletNY,2,INTEGER,0,10000,,,NumWBN,WBNNumRch,
//CT3FiletYR,3,INTEGER,0,10000,year,,NumWBN,WBNNumRch,CT3FiletNY

//CT3Fish,3,FLOAT,0,1000000,mg/kg WW,,NumWBN,WBNNumRch,CT3FishNY
//CT3FishNY,2,INTEGER,0,10000,,,NumWBN,WBNNumRch,
//CT3FishYR,3,INTEGER,0,10000,year,,NumWBN,WBNNumRch,CT3FishNY

//CT4Filet,3,FLOAT,0,1000000,mg/kg WW,,NumWBN,WBNNumRch,CT4FiletNY
//CT4FiletNY,2,INTEGER,0,10000,,,NumWBN,WBNNumRch,
//CT4FiletYR,3,INTEGER,0,10000,year,,NumWBN,WBNNumRch,CT4FiletNY

//CT4Fish,3,FLOAT,0,1000000,mg/kg WW,,NumWBN,WBNNumRch,CT4FishNY
//CT4FishNY,2,INTEGER,0,10000,,,NumWBN,WBNNumRch,
//CT4FishYR,3,INTEGER,0,10000,year,,NumWBN,WBNNumRch,CT4FishNY
  public void write(PrintStream ps)
  {
    int n;
    setCaption("Aquatic Foodweb");
    io.addRWGroup(sl);
    io.addRWGroup(af);
    addChart("Conc. AQ mp","Caqmp","mg/kg WW");
    addChart("Conc. Benth FF","Cbenthff","unitless");
    addChart("Conc. T3 Filet","CT3Filet","mg/kg WW");
    addChart("Conc. T3 Fish","CT3Fish","mg/kg WW");
    addChart("Conc. T4 Filet","CT4Filet","mg/kg WW");
    addChart("Conc. T4 Fish","CT4Fish","mg/kg WW");
    io.removeGroup(af);
    io.removeGroup(sl);
    super.write(ps);
  }
}