package gov.epa.hwir.util;

import java.io.*;

public class Index extends Value
{
  String Value;
  public Index(String group,String name,String units,int idx[],String newValue)
  {
    super(group,name,units,idx);
    Value=newValue;
  }
  public void writeValue(PrintStream ps)
  {
    ps.print(Value);
    ps.print(',');
  }
}
