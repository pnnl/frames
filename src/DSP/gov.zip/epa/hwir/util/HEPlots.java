package gov.epa.hwir.util;

import java.io.*;
import GNUPlot.Chart;
import GNUPlot.Series;

public class HEPlots extends Plots {
  String sl,he;
  hwirio io;
  public HEPlots(String newSiteLayout) {
    sl=newSiteLayout;
    he="he.grf";
    io=new hwirio();
  }
  private boolean add2DCohortChart(Chart c,String variable,String units,String numvar,int cohort)
  {
    int num;
    boolean atLeastOne=false;
    String varny=variable+"NY";
    String varyr=variable+"YR";
    if (numvar.equalsIgnoreCase("numfarm"))
      num=io.readInt(sl,numvar,"");
    else
      num=io.readInt(sl,numvar,"unitless");
    if (num==0) return false;
    for (int k=0;k<num;k++)
    {
      int n=io.readInt(he,varny,"",k+1,cohort+1);
      Series y=new Series();
      Series x=new Series();
      for (int i=0;i<n;i++)
      {
        atLeastOne=true;
        x.add(io.readInt(he,varyr,"year",k+1,cohort+1,i+1));
        y.add(io.readReal(he,variable,units,k+1,cohort+1,i+1));
      }
      y.setLabel(variable+" ("+(k+1)+","+(cohort+1)+")");
      if (n>=2)
      {
        c.addSeries(y);
        c.addXSeries(x);
      }
    }
    return atLeastOne;
  }
  private void add2DChart(String title,String variable,String units,String numvar)
  {
    int num;
    Chart c=new Chart();
    boolean atLeastOne=false;
    c.setTitle(title);
    c.setLabels("year",units);
    for (int i=0;i<4;i++)
      if (add2DCohortChart(c,variable,units,numvar,i))
        atLeastOne=true;
    if (atLeastOne) addPlot(c);
  }

  public void write(PrintStream ps)
  {
    int n;
    setCaption("Human Exposure");
    io.addRWGroup(sl);
    io.addRWGroup(he);
//Cambient_Farm,3, FLOAT,0,1.00E+06, mg/m3, , NumFarm, NumCohort, Cambient_FarmNY
//Cambient_FarmNY,2,INTEGER,0,1.00E+06, ,NumFarm,NumCohort,,
//Cambient_FarmYR,3, INTEGER,0,1.00E+06, Year, NumFarm, NumCohort, Cambient_FarmNY,
    add2DChart("Conc. Air Farm","Cambient_Farm","mg/m3","numfarm");
//Cambient_HumRcp,3, FLOAT,0,1.00E+06, mg/m3, , NumHumRcp, NumCohort, Cambient_HumRcpNY
//Cambient_HumRcpNY,2,INTEGER,0,1.00E+06, ,NumHumRcp,NumCohort,,
//Cambient_HumRcpYR,3, INTEGER,0,1.00E+06, Year, NumHumRcp, NumCohort, Cambient_HumRcpNY,
    add2DChart("Conc. Air Human","Cambient_HumRcp","mg/m3","numhumrcp");
//Csb_Farm,3, FLOAT,0,1.00E+06, mg/m3, , NumFarm, NumCohort, Csb_FarmNY
//Csb_FarmNY,2,INTEGER,0,1.00E+06,  ,NumFarm,NumCohort,,
//Csb_FarmYR,3, INTEGER,0,1.00E+06, Year, NumFarm, NumCohort, Csb_FarmNY,
    add2DChart("Conc. Shower Farm","Csb_Farm","mg/m3","numfarm");
//Csb_HumRcp,3, FLOAT,0,1.00E+06, mg/m3, , NumHumRcp, NumCohort, Csb_HumRcpNY
//Csb_HumRcpNY,2,INTEGER,0,1.00E+06, ,NumHumRcp,NumCohort,,
//Csb_HumRcpYR,3, INTEGER,0,1.00E+06, Year, NumHumRcp, NumCohort, Csb_HumRcpNY,
    add2DChart("Conc. Shower Human","Csb_HumRcp","mg/m3","numhumrcp");
//IngBeef_Farm,3, FLOAT,0,1.00E+06, mg/kg-d, , NumFarm, NumCohort, IngBeef_FarmNY
//IngBeef_FarmNY,2,INTEGER,0,1.00E+06, ,NumFarm,NumCohort,,
//IngBeef_FarmYR,3, INTEGER,0,1.00E+06, Year, NumFarm, NumCohort, IngBeef_FarmNY
    add2DChart("Ing. Beef Farm","IngBeef_Farm","mg/kg-d","numfarm");
//IngFish_Farm,3, FLOAT,0,1.00E+06, mg/kg-d, , NumFarm, NumCohort, IngFish_FarmNY
//IngFish_FarmNY,2,INTEGER,0,1.00E+06, ,NumFarm,NumCohort,,
//IngFish_FarmYR,3, INTEGER,0,1.00E+06, Year, NumFarm, NumCohort, IngFish_FarmNY,
    add2DChart("Ing. Fish Farm","IngFish_Farm","mg/kg-d","numfarm");
//IngFish_HumRcp,3, FLOAT,0,1.00E+06, mg/kg-d, , NumHumRcp, NumCohort, IngFish_HumRcpNY
//IngFish_HumRcpNY,2,INTEGER,0,1.00E+06, ,NumHumRcp,NumCohort,,
//IngFish_HumRcpYR,3, INTEGER,0,1.00E+06, Year, NumHumRcp, NumCohort, IngFish_HumRcpNY,
    add2DChart("Ing. Fish Human","IngFish_HumRcp","mg/kg-d","numhumrcp");
//IngMilk_Farm,3, FLOAT,0,1.00E+06, mg/kg-d, , NumFarm, NumCohort, IngMilk_FarmNY
//IngMilk_FarmNY,2,INTEGER,0,1.00E+06, ,NumFarm,NumCohort,,
//IngMilk_FarmYR,3, INTEGER,0,1.00E+06, Year, NumFarm, NumCohort, IngMilk_FarmNY,
    add2DChart("Ing. Milk Farm","IngMilk_Farm","mg/kg-d","numfarm");
//IngSoil_Farm,3, FLOAT,0,1.00E+06, mg/kg-d, , NumFarm, NumCohort, IngSoil_FarmNY
//IngSoil_FarmNY,2,INTEGER,0,1.00E+06, ,NumFarm,NumCohort,,
//IngSoil_FarmYR,3, INTEGER,0,1.00E+06, Year, NumFarm, NumCohort, IngSoil_FarmNY,
    add2DChart("Ing. Soil Farm","IngSoil_Farm","mg/kg-d","numfarm");
//IngSoil_HumRcp,3, FLOAT,0,1.00E+06, mg/kg-d, , NumHumRcp, NumCohort, IngSoil_HumRcpNY
//IngSoil_HumRcpNY,2,INTEGER,0,1.00E+06, ,NumHumRcp,NumCohort,,
//IngSoil_HumRcpYR,3, INTEGER,0,1.00E+06, Year, NumHumRcp, NumCohort, IngSoil_HumRcpNY,
    add2DChart("Ing. Soil Human","IngSoil_HumRcp","mg/kg-d","numhumrcp");
//IngVeg_Farm,3, FLOAT,0,1.00E+06, mg/kg-d, , NumFarm, NumCohort, IngVeg_FarmNY
//IngVeg_FarmNY,2,INTEGER,0,1.00E+06, ,NumFarm,NumCohort,,
//IngVeg_FarmYR,3, INTEGER,0,1.00E+06, Year, NumFarm, NumCohort, IngVeg_FarmNY,
    add2DChart("Ing. Veg. Farm","IngVeg_Farm","mg/kg-d","numfarm");
//IngVeg_HumRcp,3, FLOAT,0,1.00E+06, mg/kg-d, , NumHumRcp, NumCohort, IngVeg_HumRcpNY
//IngVeg_HumRcpNY,2,INTEGER,0,1.00E+06, ,NumHumRcp,NumCohort,,
//IngVeg_HumRcpYR,3, INTEGER,0,1.00E+06, Year, NumHumRcp, NumCohort, IngVeg_HumRcpNY,
    add2DChart("Ing. Veg. Human","IngVeg_HumRcp","mg/kg-d","numhumrcp");
//IngWater_Farm,3, FLOAT,0,1.00E+06, mg/kg-d, , NumFarm, NumCohort, IngWater_FarmNY
//IngWater_FarmNY,2,INTEGER,0,1.00E+06, ,NumFarm,NumCohort,,
//IngWater_FarmYR,3, INTEGER,0,1.00E+06, Year, NumFarm, NumCohort, IngWater_FarmNY,
    add2DChart("Ing. Water Farm","IngWater_Farm","mg/kg-d","numfarm");
//IngWater_HumRcp,3, FLOAT,0,1.00E+06, mg/kg-d, , NumHumRcp, NumCohort, IngWater_HumRcpNY
//IngWater_HumRcpNY,2,INTEGER,0,1.00E+06, ,NumHumRcp,NumCohort,,
//IngWater_HumRcpYR,3, INTEGER,0,1.00E+06, Year, NumHumRcp, NumCohort, IngWater_HumRcpNY,
    add2DChart("Ing. Water Human","IngWater_HumRcp","mg/kg-d","numhumrcp");
//InhAir_Farm,3, FLOAT,0,1.00E+06, mg/kg-d, , NumFarm, NumCohort, InhAir_FarmNY
//InhAir_FarmNY,2,INTEGER,0,1.00E+06, ,NumFarm,NumCohort,,
//InhAir_FarmYR,3, INTEGER,0,1.00E+06, Year, NumFarm, NumCohort, InhAir_FarmNY,
    add2DChart("Inh. Air Farm","InhAir_Farm","mg/kg-d","numfarm");
//InhAir_HumRcp,3, FLOAT,0,1.00E+06, mg/kg-d, , NumHumRcp, NumCohort, InhAir_HumRcpNY
//InhAir_HumRcpNY,2,INTEGER,0,1.00E+06, ,NumHumRcp,NumCohort,,
//InhAir_HumRcpYR,3, INTEGER,0,1.00E+06, Year, NumHumRcp, NumCohort, InhAir_HumRcpNY,
    add2DChart("Inh. Air Human","InhAir_HumRcp","mg/kg-d","numhumrcp");
//InhShower_Farm,3, FLOAT,0,1.00E+06, mg/kg-d, , NumFarm, NumCohort, InhShower_FarmNY
//InhShower_FarmNY,2,INTEGER,0,1.00E+06, ,NumFarm,NumCohort,,
//InhShower_FarmYR,3, INTEGER,0,1.00E+06, Year, NumFarm, NumCohort, InhShower_FarmNY,
    add2DChart("Inh. Shower Farm","InhShower_Farm","mg/kg-d","numfarm");
//InhShower_HumRcp,3, FLOAT,0,1.00E+06, mg/kg-d, , NumHumRcp, NumCohort, InhShower_HumRcpNY
//InhShower_HumRcpNY,2,INTEGER,0,1.00E+06, ,NumHumRcp,NumCohort,,
//InhShower_HumRcpYR,3, INTEGER,0,1.00E+06, Year, NumHumRcp, NumCohort, InhShower_HumRcpNY,}
    add2DChart("Inh. Shower Human","InhShower_HumRcp","mg/kg-d","numhumrcp");
//IngBMBeefF,2, FLOAT,0,1.00E+06, mg/kg-d, , NumFarm, IngBMBeefFNY
//IngBMBeefFNY,1,INTEGER,0,1.00E+06, ,NumFarm,,
//IngBMBeefFYR,2, INTEGER,0,1.00E+06, Year, NumFarm, , IngBMBeefFNY
//IngBMFisherBeefF,2, FLOAT,0,1.00E+06, mg/kg-d, , NumFarm, IngBMFisherBeefFNY
//IngBMFisherBeefFNY,1,INTEGER,0,1.00E+06, ,NumFarm,,
//IngBMFisherBeefFYR,2, INTEGER,0,1.00E+06, Year, NumFarm, , IngBMFisherBeefFNY
//IngBMFisherGardenerH,2, FLOAT,0,1.00E+06, mg/kg-d, , NumHumRcp, IngBMFisherGardenerHNY
//IngBMFisherGardenerHNY,1,INTEGER,0,1.00E+06, ,NumHumRcp,,
//IngBMFisherGardenerHYR,2, INTEGER,0,1.00E+06, Year, NumHumRcp, , IngBMFisherGardenerHNY
//IngBMFisherMilkF,2, FLOAT,0,1.00E+06, mg/kg-d, , NumFarm, IngBMFisherMilkFNY
//IngBMFisherMilkFNY,1,INTEGER,0,1.00E+06, ,NumFarm,,
//IngBMFisherMilkFYR,2, INTEGER,0,1.00E+06, Year, NumFarm, , IngBMFisherMilkFNY
//IngBMFisherResidentH,2, FLOAT,0,1.00E+06, mg/kg-d, , NumHumRcp, IngBMFisherResidentHNY
//IngBMFisherResidentHNY,1,INTEGER,0,1.00E+06, ,NumHumRcp,,
//IngBMFisherResidentHYR,2, INTEGER,0,1.00E+06, Year, NumHumRcp, , IngBMFisherResidentHNY
//IngBMGardenerH,2, FLOAT,0,1.00E+06, mg/kg-d, , NumHumRcp, IngBMGardenerHNY,
//IngBMGardenerHNY,1,INTEGER,0,1.00E+06, ,NumHumRcp,,,
//IngBMGardenerHYR,2, INTEGER,0,1.00E+06, Year, NumHumRcp, , IngBMGardenerHNY,
//IngBMMilkF,2, FLOAT,0,1.00E+06, mg/kg-d, , NumFarm, IngBMMilkFNY,
//IngBMMilkFNY,1,INTEGER,0,1.00E+06, ,NumFarm,,,
//IngBMMilkFYR,2, INTEGER,0,1.00E+06, Year, NumFarm, , IngBMMilkFNY,
//IngBMResidentH,2, FLOAT,0,1.00E+06, mg/kg-d, , NumHumRcp, IngBMResidentHNY,
//IngBMResidentHNY,1,INTEGER,0,1.00E+06, ,NumHumRcp,,,
//IngBMResidentHYR,2, INTEGER,0,1.00E+06, Year, NumHumRcp, , IngBMResidentHNY,
    io.removeGroup(he);
    io.removeGroup(sl);
    super.write(ps);
  }
}