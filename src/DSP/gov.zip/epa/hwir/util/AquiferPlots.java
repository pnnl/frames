package gov.epa.hwir.util;

import java.io.*;
import GNUPlot.Series;
import GNUPlot.Chart;

public class AquiferPlots extends Plots {
  String sl,aq,cp;
  hwirio io;
  int numPlumeWell;
  int indices[];
  public AquiferPlots(String newSL)
  {
    sl=newSL;
    cp="cpaq.ssf";
    io=new hwirio();
  }
  private void countWells()
  {
    int numWells=io.readInt(sl,"NumAquWell","",1);
    indices=new int[numWells];
    numPlumeWell=0;
    for (int i=0;i<numWells;i++)
    {
      if (io.readLog(aq,"AquWellConcFlag","",i+1))
      {
        indices[numPlumeWell]=i+1;
        numPlumeWell++;
      }
    }
  }
//AquRchMassFlux,2,Float,0,1.00E+15,g/yr,Mass Flux from Aquifer to Reach,NumChem,AquRchMassFluxNY,
//AquRchMassFluxNY,1,Integer,0,10000, ,Number of Time - Mass-Flux-to-Reach Pairs,NumChem,,
//AquRchMassFluxYR,2,Float,0,10000,year,Time of Mass Flux from Aquifer to Reach,NumChem,AquRchMassFluxNY,
//AquRchWaterFlux,0,Float,0,2.00E+13,m3/day,Total GW Flux to Reach,,,
  private void addAquRchMassFluxChart(int numChemIndex)
  {
    Chart c=new Chart();
    c.setTitle("Mass Flux from Aquifer");
    c.setLabels("year","g/yr");
    String variable="AquRchMassFlux";
    String varny="AquRchMassFluxNY";
    String varyr="AquRchMassFluxYR";
    int n=io.readInt(aq,varny,"",numChemIndex+1);
    Series x=new Series();
    Series y=new Series();
    for (int i=0;i<n;i++)
    {
      x.add(io.readReal(aq,varyr,"year",numChemIndex+1,i+1));
      y.add(io.readReal(aq,variable,"g/yr",numChemIndex+1,i+1));
    }
    y.setLabel("AquRchMassFlux "+io.readString(cp,"ChemName","",numChemIndex+1));
    c.addSeries(y);
    c.addXSeries(x);
    if (n>=2) addPlot(c);
  }

  private void addAllAquRchMassFluxChart()
  {
//    int nc=io.readInt(cp,"NumChem","");
//    for (int i=0;i<nc;i++)
      addAquRchMassFluxChart(0);
  }


//AquWellConc,3,Float,0,1000000,mg/L,Obs. Well Conc.,AquWellNum,NumChem,AquWellConcNY
//AquWellConcFlag,1,Logical,,, ,"Flag indicating well is within plume: T - yes, F - no",AquWellNum,,
//AquWellConcNY,2,Integer,0,10000, ,Number of Time - Obs. Well Conc Pairs,AquWellNum,NumChem,
//AquWellConcYr,3,Integer,0,10000,year,Time of Obs. Well Conc.,AquWellNum,NumChem,AquWellConcNY
  private void addAquWellConcChart(int numChemIndex)
  {
    Chart c=new Chart();
    c.setTitle("Obs. Well Conc.");
    c.setLabels("year","mg/L");
    String variable="AquWellConc";
    String varny="AquWellConcNY";
    String varyr="AquWellConcYR";
    for (int j=0;j<numPlumeWell;j++)
    {
      int n=io.readInt(aq,varny,"",indices[j],numChemIndex+1);
      Series x=new Series();
      Series y=new Series();
      for (int i=0;i<n;i++)
      {
        x.add(io.readInt(aq,varyr,"year",indices[j],numChemIndex+1,i+1));
        y.add(io.readReal(aq,variable,"mg/L",indices[j],numChemIndex+1,i+1));
      }
      y.setLabel("AquWellConc "+io.readString(cp,"ChemName","",numChemIndex+1)+"("+indices[j]+")");
      c.addSeries(y);
      c.addXSeries(x);
    }
    if (numPlumeWell>0) addPlot(c);
  }

  private void addAllAquWellConcChart()
  {
//    int nc=io.readInt(cp,"NumChem","");
//    countWells();
//    for (int i=0;i<nc;i++)
      addAquWellConcChart(0);
  }

  public void write(PrintStream ps)
  {
    int n;
    io.addRWGroup(sl);
    aq="aq"+io.readString(sl,"AquID","",1)+".grf";
    io.addRWGroup(aq);
    io.addRWGroup(cp);
    setCaption("Aquifer");
    addAllAquWellConcChart();
    addAllAquRchMassFluxChart();
    io.removeGroup(cp);
    io.removeGroup(aq);
    io.removeGroup(sl);
    super.write(ps);
  }
}