package gov.epa.hwir.util;

import java.io.*;
import GNUPlot.Chart;
import GNUPlot.Series;

public class AirPlots extends Plots{

  String sl,ar;
  hwirio io;
  public AirPlots(String newSiteLayoutFile)
  {
    sl=newSiteLayoutFile;
    ar="ar.grf";
    io=new hwirio();
  }
  private void addChart(String checkVar,String title,String units,String variable)
  {
    if (!io.readLog(ar,checkVar,"")) return;
    boolean atLeastOne=false;
    String varny=variable+"NY";
    String varyr=variable+"YR";
    Chart c=new Chart();
    c.setTitle(title);
    c.setLabels("year",units);
    int num=io.readInt(sl,"NumAir","");
    for (int j=0;j<num;j++)
    {
      Series x=new Series();
      Series y=new Series();
      int n=io.readInt(ar,varny,"",j+1);
      for (int i=0;i<n;i++)
      {
//        if (j==0)
        atLeastOne=true;
          x.addUnique((double)io.readInt(ar,varyr,"year",j+1,i+1));
        y.add(io.readReal(ar,variable,units,j+1,i+1));
      }
      y.setLabel(variable+"("+(j+1)+")");
      c.addSeries(y);
      c.addXSeries(x);
    }
    if (atLeastOne) addPlot(c);
  }

  public void write(PrintStream ps)
  {
    int n;
    io.addRWGroup(sl);
    io.addRWGroup(ar);
    setCaption("Air");
    addChart("srcVE","Vapor Concentration","ug/m3","CVap");
    addChart("srcCE","PM10 Concentration","ug/m3","PM10");
    addChart("srcVE","Vapor Wet Deposition","g/m2/d","VapWDep");
    addChart("srcCE","PM10 Dry Deposition","g/m2/d","ParDDep");
    addChart("srcCE","PM10 Wet Deposition","g/m2/d","ParWDep");
    io.removeGroup(ar);
    io.removeGroup(sl);
    super.write(ps);
  }

}