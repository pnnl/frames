package gov.epa.hwir.util;

import java.io.*;
import GNUPlot.Chart;
import GNUPlot.Series;

public class FFPlots extends Plots {
  String sl,ff;
  hwirio io;
  public FFPlots(String newSiteLayout) {
    sl=newSiteLayout;
    ff="ff.grf";
    io=new hwirio();
  }
  private void add2DChart(String title,String variable,String units,String numvar)
  {
    int num;
    Chart c=new Chart();
    boolean atLeastOne=false;
    c.setTitle(title);
    c.setLabels("year",units);
    String varny=variable+"NY";
    String varyr=variable+"YR";
    if (numvar.equalsIgnoreCase("numfarm"))
      num=io.readInt(sl,numvar,"");
    else
      num=io.readInt(sl,numvar,"unitless");
    if (num==0) return;
    for (int k=0;k<num;k++)
    {
      int n=io.readInt(ff,varny,"",k+1);
      Series y=new Series();
      Series x=new Series();
      for (int i=0;i<n;i++)
      {
        atLeastOne=true;
        x.add(io.readInt(ff,varyr,"year",k+1,i+1));
        y.add(io.readReal(ff,variable,units,k+1,i+1));
      }
      y.setLabel(variable+" ("+(k+1)+")");
      if (n>=2)
      {
        c.addSeries(y);
        c.addXSeries(x);
      }
    }
    if (atLeastOne) addPlot(c);
  }
  public void write(PrintStream ps)
  {
    int n;
    setCaption("Farm FoodChain");
    io.addRWGroup(sl);
    io.addRWGroup(ff);
//Abeef_farm,2, FLOAT,0,1.00E+09, mg/kg WW, NumFarm, Abeef_farmNY, beef concentration
//Abeef_farmNY,1, INTEGER,0,1.00E+08,, NumFarm, beef concentration ,
//Abeef_farmYR,2, INTEGER,0,1.00E+08, Year, NumFarm, Abeef_farmYRNY, beef concentration
    add2DChart("Beef Conc.","Abeef_farm","mg/kg WW","numfarm");
//Amilk_farm,2, FLOAT,0,1.00E+09, mg/kg WW, NumFarm, Amilk_farmNY, milk concentration
//Amilk_farmNY,1, INTEGER,0,1.00E+08,, NumFarm, milk concentration ,
//Amilk_farmYR,2, INTEGER,0,1.00E+08, Year, NumFarm, Amilk_farmYRNY, milk concentration
    add2DChart("Milk Conc.","Amilk_farm","mg/kg WW","numfarm");
//CTssAve_farm,2, FLOAT,0,1.00E+09, ug/g, NumFarm, CTssAve_farmNY, concentration in root vegetables
//CTssAve_farmNY,1, INTEGER,0,1.00E+08,, NumFarm, concentration in root vegetables,
//CTssAve_farmYR,2, INTEGER,0,1.00E+08, Year, NumFarm, CTssAve_farmYRNY, concentration in root vegetables
    add2DChart("Top Soil Conc.","CTssAve_farm","ug/g","numfarm");
//Pexfruit_farm,2, FLOAT,0,1.00E+09, mg/kg WW, NumFarm, Pexfruit_farmNY, concentration in exposed above-ground fruits
//Pexfruit_farmNY,1, INTEGER,0,1.00E+08,, NumFarm, concentration in exposed above-ground fruits,
//Pexfruit_farmYR,2, INTEGER,0,1.00E+08, Year, NumFarm, Pexfruit_farmYRNY, concentration in exposed above-ground fruits
    add2DChart("Exposed Fruit Farm","Pexfruit_farm","mg/kg WW","numfarm");
//Pexfruit_garden,2, FLOAT,0,1.00E+09, mg/kg WW, NumHumRcp, Pexfruit_gardenNY, concentration in exposed above-ground fruits
//Pexfruit_gardenNY,1, INTEGER,0,1.00E+08,, NumHumRcp,, concentration in exposed above-ground fruits
//Pexfruit_gardenYR,2, INTEGER,0,1.00E+08, Year, NumHumRcp, Pexfruit_gardenYRNY, concentration in exposed above-ground fruits
    add2DChart("Exposed Fruit Gardens","Pexfruit_garden","mg/kg WW","numhumrcp");
//Pexveg_farm,2, FLOAT,0,1.00E+09, mg/kg WW, NumFarm, Pexveg_farmNY, concentration in exposed above-ground vegetables
//Pexveg_farmNY,1, INTEGER,0,1.00E+08,, NumFarm, concentration in exposed above-ground vegetables,
//Pexveg_farmYR,2, INTEGER,0,1.00E+08, Year, NumFarm, Pexveg_farmYRNY, concentration in exposed above-ground vegetables
    add2DChart("Exposed Veg. Farm","Pexveg_farm","mg/kg WW","numfarm");
//Pexveg_garden,2, FLOAT,0,1.00E+09, mg/kg WW, NumHumRcp, Pexveg_gardenNY, concentration in exposed above-ground vegetables
//Pexveg_gardenNY,1, INTEGER,0,1.00E+08,, NumHumRcp,, concentration in exposed above-ground vegetables
//Pexveg_gardenYR,2, INTEGER,0,1.00E+08, Year, NumHumRcp, Pexveg_gardenYRNY, concentration in exposed above-ground vegetables
    add2DChart("Exposed Veg. Gardens","Pexveg_garden","mg/kg WW","numhumrcp");
//Pprofruit_farm,2, FLOAT,0,1.00E+09, mg/kg WW, NumFarm, Pprofruit_farmNY, concentration in protected above-ground fruits
//Pprofruit_farmNY,1, INTEGER,0,1.00E+08,, NumFarm, concentration in protected above-ground fruits,
//Pprofruit_farmYR,2, INTEGER,0,1.00E+08, Year, NumFarm, Pprofruit_farmYRNY, concentration in protected above-ground fruits
    add2DChart("Protected Fruit Farm","Pprofruit_farm","mg/kg WW","numfarm");
//Pprofruit_garden,2, FLOAT,0,1.00E+09, mg/kg WW, NumHumRcp, Pprofruit_gardenNY, concentration in protected above-ground fruits
//Pprofruit_gardenNY,1, INTEGER,0,1.00E+08,, NumHumRcp,, concentration in protected above-ground fruits
//Pprofruit_gardenYR,2, INTEGER,0,1.00E+08, Year, NumHumRcp, Pprofruit_gardenYRNY, concentration in protected above-ground fruits
    add2DChart("Protected Fruit Gardens","pprofruit_garden","mg/kg WW","numhumrcp");
//Pproveg_farm,2, FLOAT,0,1.00E+09, mg/kg WW, NumFarm, Pproveg_farmNY, concentration in protected above-ground vegetables
//Pproveg_farmNY,1, INTEGER,0,1.00E+08,, NumFarm, concentration in protected above-ground vegetables,
//Pproveg_farmYR,2, INTEGER,0,1.00E+08, Year, NumFarm, Pproveg_farmYRNY, concentration in protected above-ground vegetables
    add2DChart("Protected Veg. Farm","Pproveg_farm","mg/kg WW","numfarm");
//Pproveg_garden,2, FLOAT,0,1.00E+09, mg/kg WW, NumHumRcp, Pproveg_gardenNY, concentration in protected above-ground vegetables
//Pproveg_gardenNY,1, INTEGER,0,1.00E+08,, NumHumRcp,, concentration in protected above-ground vegetables
//Pproveg_gardenYR,2, INTEGER,0,1.00E+08, Year, NumHumRcp, Pproveg_gardenYRNY, concentration in protected above-ground vegetables
    add2DChart("Protected Veg. Gardens","pproveg_garden","mg/kg WW","numhumrcp");
//Proot_farm,2, FLOAT,0,1.00E+09, mg/kg WW, NumFarm, Proot_farmNY, concentration in root vegetables
//Proot_farmNY,1, INTEGER,0,1.00E+08,, NumFarm,, concentration in root vegetables
//Proot_farmYR,2, INTEGER,0,1.00E+08, Year, NumFarm, Proot_farmYRNY, concentration in root vegetables
    add2DChart("Protected Root Farm","Proot_farm","mg/kg WW","numfarm");
//Proot_garden,2, FLOAT,0,1.00E+09, mg/kg WW, NumHumRcp, Proot_gardenNY, concentration in root vegetables
//Proot_gardenNY,1, INTEGER,0,1.00E+08,, NumHumRcp,, concentration in root vegetables
//Proot_gardenYR,2, INTEGER,0,1.00E+08, Year, NumHumRcp, Proot_gardenYRNY, concentration in root vegetables
    add2DChart("Protected Root Gardens","proot_garden","mg/kg WW","numhumrcp");
    io.removeGroup(ff);
    io.removeGroup(sl);
    super.write(ps);
  }
}