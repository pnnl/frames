package gov.epa.hwir.util;

import java.util.*;
import java.io.*;
import GNUPlot.Chart;

public class Plots {
  Vector Charts;
  String Caption;
  public Plots() {
    Charts=new Vector();
    Caption=new String("Unset caption");
  }
  public void setCaption(String newCaption)
  {
    Caption=newCaption;
  }
  public void addPlot(Chart newChart)
  {
    Charts.add(newChart);
  }
  public void write(PrintStream ps)
  {
    int count=0;
    String labels[];
    Chart c;
    ps.println("<Font Size=+1><B>"+Caption+"</B></Font>");
    ps.println("<TABLE Border=1>");
    ps.println("<TR>");
    Enumeration e=Charts.elements();
    while (e.hasMoreElements())
    {
      c=(Chart)e.nextElement();
      String s=c.generate();
      ps.println("<TD>");
      ps.println("<center>"+c.getTitle()+"</Center>");
//      ps.println("<Table><tr><td>");  // Legend beside graph
      ps.println("<A href='"+s+"'>");
      ps.println("<IMG SRC='"+s+"' HEIGHT=80 WIDTH=160>");
      ps.println("</A>");
//      labels=c.getLabels();
//      ps.println("</td><td>");
//      for (int i=0;i<labels.length;i++)
//        ps.println("<font size=-3>"+labels[i]+"</font><br>");
//      ps.println("</td></tr></table>"); // End image legend table
      ps.println("</TD>");
      count++;
      if (count==4)
      {
        count=0;
        ps.println("</TR><TR>");
      }
    }
    ps.println("</TR>");
    ps.println("</TABLE>");
  }
}
