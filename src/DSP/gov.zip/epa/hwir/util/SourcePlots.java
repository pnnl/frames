package gov.epa.hwir.util;

import GNUPlot.Chart;
import GNUPlot.Series;
import java.io.*;

//SrcCE,0,logical,,,,flag for chemical sorbed to particulates emissions presence,,
//SrcH2O,0,logical,,,,flag for surface water presence,,
//SrcLeachMet,0,logical,,,,flag for leachate presence when leachate is met-driven,,
//SrcLeachSrc,0,logical,,,, flag for leachate presence when leachate is not met-driven (unit is active),,
//SrcOvl,0,logical,,,, flag for overland flow presence,,
//SrcSoil,0,logical,,,,flag for soil presence,,
//SrcVE,0,logical,,,,flag for volatile emissions presence,,


public class SourcePlots extends Plots{
  String sl,sr;
  hwirio io;
  public SourcePlots(String newSiteLayoutFile)
  {
    sl=newSiteLayoutFile;
    sr="sr.grf";
    io=new hwirio();
  }

//NyrMet,0,integer,1,100,year,number of years in the available met record,,,,,
  private void add1DNYRMet(String Title,String variable,String units)
  {
    Chart c=new Chart();
    c.setTitle(Title);
    c.setLabels("year",units);
    Series x=new Series();
    Series y=new Series();
    int numlws=io.readInt(sl,"SrcNumLWS","");
    int n=io.readInt(sr,"NYrMet","year");
    for (int i=0;i<n;i++)
      x.add((double)i+1);
    for (int j=0;j<numlws;j++)
    {
      for (int i=0;i<n;i++)
        y.add(io.readReal(sr,variable,units,j+1,i+1));
      y.setLabel(variable+"("+(j+1)+")");
      c.addSeries(y);
      c.addXSeries(x);
    }
//    c.setXSeries(x);
    addPlot(c);
  }


  private void add1DLWSChart(Chart c,String units,String variable)
  {
    String varny=variable+"NY";
    String varyr=variable+"YR";
    Series x=new Series();
    Series x2=new Series();
    int numLWS,lwsNumSubArea;
    numLWS=io.readInt(sl,"SrcNumLWS","");
    for (int j=0;j<numLWS;j++)
    {
      int n=io.readInt(sr,varny,"",j+1);
      Series y=new Series();
      for (int i=0;i<n;i++)
      {
        x.addUnique((double)io.readInt(sr,varyr,"year",j+1,i+1));
        y.add(io.readReal(sr,variable,units,j+1,i+1));
      }
      y.setLabel(variable+"("+(j+1)+")");
      c.addSeries(y);
      c.addXSeries(x);
    }
  }

//SWLoadChem,2,float,0,1.00E+08,g/d,chemical load to waterbody,NumLWS,SWLoadChemNY
//SWLoadChemNY,1,integer,0,10000,,number of years in outputs,NumLWS,
//SWLoadChemYR,2,integer,1,10000,year,year associated with output,NumLWS,SWLoadChemNY
  private void addSWLoadChemChart()
  {
    if (!io.readLog(sr,"SrcOVL","")) return;
    Chart c=new Chart();
    c.setTitle("SW Load Chem/Solid");
    c.setLabels("year","g/d");
    add1DLWSChart(c,"g/d","SWLoadChem");
    addPlot(c);
  }

//SWConcTot,1,float,0,1.00E+05,mg/L,total chem concentration in surface water,SWConcTotNY,
//SWConcTotNY,0,integer,0,10000,,number of years in outputs,,
//SWConcTotYR,1,integer,1,10000,year,year associated with output,SWConcTotNY,
  private void addSWConcTotChart()
  {
    if (!io.readLog(sr,"SrcH2O","")) return;
    Chart c=new Chart();
    c.setTitle("Source SW Conc.");
    c.setLabels("year","mg/L");
    add1DChart(c,"mg/L","SWConcTot");
    addPlot(c);
  }

//PMF,2,float,0,1,mass fraction,particulate emission particle size distribution,PMFNY,4
//PMFNY,0,integer,0,10000,,number of years in outputs,,
//PMFYR,1,integer,1,10000,year,year associated with output,PMFNY,
  private void addPMFChart()
  {
    if (!io.readLog(sr,"SrcCE","")) return;
    Chart c=new Chart();
    c.setTitle("Particle");
    c.setLabels("year","mass fraction");
    String variable="PMF";
    String varny=variable+"NY";
    String varyr=variable+"YR";
    Series x=new Series();
    Series y[]=new Series[4];
    for (int j=0;j<4;j++)
    {
      y[j]=new Series();
      y[j].setLabel(variable+"("+(j+1)+")");
      c.addSeries(y[j]);
      c.addXSeries(x);
    }
    int n=io.readInt(sr,varny,"");
    for (int i=0;i<n;i++)
    {
      x.add((double)io.readInt(sr,varyr,"year",i+1));
      for (int j=0;j<4;j++)
        y[j].add(io.readReal(sr,variable,"mass fraction",j+1,i+1));
    }
//    c.setXSeries(x);
    addPlot(c);
  }

  private void add2DLWSChart(Chart c,String units,String variable)
  {
    String varny=variable+"NY";
    String varyr=variable+"YR";
    Series x=new Series();
    Series x2=new Series();
    int numLWS,lwsNumSubArea;
    numLWS=io.readInt(sl,"SrcNumLWS","");
    for (int j=0;j<numLWS;j++)
    {
      lwsNumSubArea=io.readInt(sl,"SrcLWSNumSubArea","",j+1);
      for (int k=0;k<lwsNumSubArea;k++)
      {
        int n=io.readInt(sr,varny,"",j+1,k+1);
        Series y=new Series();
        for (int i=0;i<n;i++)
        {
//          if (j==0 && k==0) // assumes first series is the longest
//          {
            x.addUnique((double)io.readInt(sr,varyr,"year",j+1,k+1,i+1));
//          }
          y.add(io.readReal(sr,variable,units,j+1,k+1,i+1));
        }
        y.setLabel(variable+"("+(j+1)+","+(k+1)+")");
        c.addSeries(y);
        c.addXSeries(x);
      }
    }
//    c.setXSeries(x);
  }

  private boolean add1DChart(Chart c,String units,String variable)
  {
    String varny=variable+"NY";
    String varyr=variable+"YR";
    Series x=new Series();
    Series y=new Series();
    int n=io.readInt(sr,varny,"");
    for (int i=0;i<n;i++)
    {
      x.add((double)io.readInt(sr,varyr,"year",i+1));
      y.add(io.readReal(sr,variable,units,i+1));
    }
//    if (n>0) c.setXSeries(x);
    y.setLabel(variable);
    if (n>0)
    {
      c.addSeries(y);
      c.addXSeries(x);
    }
    return n>0;
  }

  private void addReleaseChart()
  {
//"SrcLeachMet",0,"LOGICAL",0,"",
//"T",
//"SrcCE",0,"LOGICAL",0,"",
//"T",
//"SrcVE",0,"LOGICAL",0,"",
//"T",
    boolean atLeastOne=false;
    if (!io.readLog(sr,"srcLeachMet","") &&
        !io.readLog(sr,"SrcCe","") &&
        !io.readLog(sr,"SrcVe","")) return;
    Chart c=new Chart();
    c.setTitle("Release flux");
    c.setLabels("year","g/m2/d");
    if (io.readLog(sr,"SrcLeachSrc",""))
    {
      addLeachFluxChart(c);
      atLeastOne=true;
    }
    if (io.readLog(sr,"SrcCe",""))
    {
      add1DChart(c,"g/m2/d","CE");
      add1DChart(c,"g/m2/d","PE30");
      atLeastOne=true;
    }
    if (io.readLog(sr,"SrcVe",""))
    {
      atLeastOne=add1DChart(c,"g/m2/d","VE");
    }
    if (atLeastOne) addPlot(c);
  }

  private void addLeachFluxChart(Chart c)
  {
//"LeachFlux",2,"FLOAT",0,"g/m2/d",
//1,
//30,2.428206951e-005,2.428257592e-005,2.428257592e-005,2.428257592e-005,2.428257592e-005,2.428257592e-005,2.428257592e-005,2.428257592e-005,2.428257592e-005,2.428257592e-005,2.428257592e-005,2.428257592e-005,2.428257592e-005,2.428257592e-005,2.428257592e-005,2.428257592e-005,2.428257592e-005,2.428257592e-005,2.428257592e-005,2.428257592e-005,2.428257592e-005,2.428257592e-005,2.428257592e-005,2.428257592e-005,2.428257592e-005,2.428257592e-005,2.428257592e-005,2.428257592e-005,2.428257592e-005,5.064046247e-010,
//"LeachFluxNY",1,"INTEGER",0,"",
//1,30,
//"LeachFluxYR",2,"INTEGER",0,"year",
//1,
//30,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,
    boolean atLeastOne=false;
    int numLWS=io.readInt(sl,"SrcNumLWS","");
    for (int j=0;j<numLWS;j++)
    {
      Series y=new Series();
      Series x=new Series();
        int n=io.readInt(sr,"LeachFluxNY","",j+1);
      for (int i=0;i<n;i++)
      {
        atLeastOne=true;
        x.add((double)io.readInt(sr,"LeachFluxYR","year",j+1,i+1));
        y.add(io.readReal(sr,"LeachFlux","g/m2/d",j+1,i+1));
      }
      y.setLabel("LeachFlux("+(j+1)+")");
      if (n>0)
      {
        c.addSeries(y);
        c.addXSeries(x);
      }
    }
//    if (atLeastOne) c.setXSeries(x);
  }

  private void addSoilConcChart()
  {
//"SrcSoil",0,"LOGICAL",0,"",
//"T",
    if(!io.readLog(sr,"SrcSoil","")) return;
//"SrcSoil",0,"LOGICAL",0,"",
//"T",
    if(!io.readLog(sr,"SrcSoil","")) return;
    Chart c=new Chart();
    c.setTitle("Soil Concentration");
    c.setLabels("year","ug/g");
    add2DLWSChart(c,"ug/g","CTss");
    add2DLWSChart(c,"ug/g","CTda");
    addPlot(c);
  }
  public void write(PrintStream ps)
  {
//Orphan flags imply missing chart types
//"SrcH2O",0,"LOGICAL",0,"",
//"F",
//"SrcLeachSrc",0,"LOGICAL",0,"",
//"F",
//"SrcOvl",0,"LOGICAL",0,"",
//"F",
    int n;
    io.addRWGroup(sl);
    io.addRWGroup(sr);
    setCaption("Source");
    addReleaseChart();
    addSWLoadChemChart();
    addPMFChart();
    addSoilConcChart();
    addSWConcTotChart();
//SrcLeachMet,0,logical,,,,flag for leachate presence when leachate is met-driven,,
//AnnInfil,2,float,0,.03,m/d,"leachate infiltration rate (annual avg., WMU subarea(s) only)",NumLWS,NyrMet,,,
    if (io.readLog(sr,"SrcLeachMet",""))
      add1DNYRMet("Leachate rate","AnnInfil","m/d");
//SrcOvl,0,logical,,,, flag for overland flow presence,,
//Runoff,2,float,0,1.00E+04,m3/d,runoff,NumLWS,NyrMet
//SWLoadSolid,2,float,0,1.00E+10,g/d,total suspended solids load to waterbody,NumLWS,NyrMet
    if (io.readLog(sr,"SrcOvl",""))
    {
      add1DNYRMet("Runoff","Runoff","m3/d");
      add1DNYRMet("TSS to SW","SWLoadSolid","g/d");
    }
    io.removeGroup(sr);
    io.removeGroup(sl);
    super.write(ps);
  }
}
