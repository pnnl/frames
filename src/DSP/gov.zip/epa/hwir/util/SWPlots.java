package gov.epa.hwir.util;

import java.io.*;
import GNUPlot.Chart;
import GNUPlot.Series;

public class SWPlots extends Plots {
  String sl,cp;
  String sw[];
  hwirio io;

  public SWPlots(String newSiteLayout) {
    cp="cpstream.ssf";
    sl=newSiteLayout;
    io=new hwirio();
  }
  private void addWBNChemChart(String title,String variable,String units,int numChemIndex)
  {
    Chart c=new Chart();
    boolean atLeastOne=false;
    c.setTitle(title);
    c.setLabels("year",units);
    String varny=variable+"NY";
    String varyr=variable+"YR";
//    Series x=new Series();
    for (int k=0;k<sw.length;k++)
    {
      int nrch=io.readInt(sl,"WBNNumRch","",k+1);
      for (int j=0;j<nrch;j++)
      {
        int n=io.readInt(sw[k],varny,"",numChemIndex+1,j+1);
        Series y=new Series();
        Series x=new Series();
        for (int i=0;i<n;i++)
        {
          atLeastOne=true;
          x.add(io.readInt(sw[k],varyr,"year",numChemIndex+1,j+1,i+1));
          y.add(io.readReal(sw[k],variable,units,numChemIndex+1,j+1,i+1));
        }
        y.setLabel(variable+" "+io.readString(cp,"ChemName","",numChemIndex+1)+"("+(k+1)+","+(j+1)+")");
        if (n>=2)
        {
          c.addSeries(y);
          c.addXSeries(x);
        }
      }
    }
    if (atLeastOne) addPlot(c);
  }
//WBNConcBenthDiss,3,Float,0,1000000,mg/L,   ;(WBNNumChem,WBNNumRch,WBNConcBenthDissNY)
//WBNConcBenthDissNY,2,Integer,0,10000,,   ;(WBNNumChem,WBNNumRch),
//WBNConcBenthDissYr,3,Integer,0,10000,year, ;(WBNNumChem,WBNNumRch,WBNConcBenthDissNY)
  public void addAllWBNConcBenthDissChart()
  {
    int n=io.readInt(cp,"NumChem","");
    for (int i=0;i<n;i++)
      addWBNChemChart("Conc. Benth. Diss.","WBNConcBenthDiss","mg/l",i);
  }
//WBNConcBenthTot,3,Float,0,1000000,ug/g,    ;(WBNNumChem,WBNNumRch,WBNConcBenthTotNY)
//WBNConcBenthTotNY,2,Integer,0,10000,,    ;(WBNNumChem,WBNNumRch),
//WBNConcBenthTotYr,3,Integer,0,10000,year,;(WBNNumChem,WBNNumRch,WBNConcBenthTotNY)
  public void addAllWBNConcBenthTotChart()
  {
    int n=io.readInt(cp,"NumChem","");
    for (int i=0;i<n;i++)
      addWBNChemChart("Conc. Benth. Total","WBNConcBenthTot","ug/g",i);
  }

//WBNConcWaterDiss,3,Float,0,1000000,mg/L,   ;(WBNNumChem,WBNNumRch,WBNConcWaterDissNY)
//WBNConcWaterDissNY,2,Integer,0,10000,,   ;(WBNNumChem,WBNNumRch),
//WBNConcWaterDissYr,3,Integer,0,10000,year, ;(WBNNumChem,WBNNumRch,WBNConcWaterDissNY)
  public void addAllWBNConcWaterDissChart()
  {
    int n=io.readInt(cp,"NumChem","");
    for (int i=0;i<n;i++)
      addWBNChemChart("Conc. Water Diss.","WBNConcWaterDiss","mg/L",i);
  }

//WBNConcWaterTot,3,Float,0,1000000,mg/L,    ;(WBNNumChem,WBNNumRch,WBNConcWaterTotNY)
//WBNConcWaterTotNY,2,Integer,0,10000,,    ;(WBNNumChem,WBNNumRch),
//WBNConcWaterTotYr,3,Integer,0,10000,year, ;(WBNNumChem,WBNNumRch,WBNConcWaterTotNY)
  public void addAllWBNConcWaterTotChart()
  {
    int n=io.readInt(cp,"NumChem","");
    for (int i=0;i<n;i++)
      addWBNChemChart("Conc. Water Total","WBNConcWaterTot","mg/L",i);
  }

  private void addWBNChart(String title,String variable,String units)
  {
    Chart c=new Chart();
    boolean atLeastOne=false;
    c.setTitle(title);
    c.setLabels("year",units);
    String varny=variable+"NY";
    String varyr=variable+"YR";
    for (int k=0;k<sw.length;k++)
    {
      int nrch=io.readInt(sl,"WBNNumRch","",k+1);
      for (int j=0;j<nrch;j++)
      {
        int n=io.readInt(sw[k],varny,"",j+1);
        Series y=new Series();
        Series x=new Series();
        for (int i=0;i<n;i++)
        {
          atLeastOne=true;
          x.add(io.readInt(sw[k],varyr,"year",j+1,i+1));
          y.add(io.readReal(sw[k],variable,units,j+1,i+1));
        }
        y.setLabel(variable+" ("+(k+1)+","+(j+1)+")");
        if (n>=2)
        {
          c.addSeries(y);
          c.addXSeries(x);
        }
      }
    }
    if (atLeastOne) addPlot(c);
  }

//WBNfocBenth,2,Float,0,0.5,fraction,      ;(WBNNumRch,WBNfocBenthNY),
//WBNfocBenthNY,1,Integer,0,10000,,        ;(WBNNumRch),,
//WBNfocBenthYr,2,Integer,0,10000,year,    ;(WBNNumRch,WBNfocBenthNY)
//WBNNumChem,0,Integer,1,10,,              ;number of chemicals in output file,
//WBNTSSWater,2,Float,0,70000,mg/L,        ;(WBNNumRch,WBNTSSWaterNY)
//WBNTSSWaterNY,1,Integer,0,10000,,        ;(WBNNumRch),
//WBNTSSWaterYr,2,Integer,0,10000,year,    ;(WBNNumRch,WBNTSSWaterNY)

  public void write(PrintStream ps)
  {
    int n;
    setCaption("Surface Water");
    io.addRWGroup(sl);
    io.addRWGroup(cp);
    n=io.readInt(sl,"NumWBN","");
    if (n>0)
    {
      sw=new String[n];
      for (int i=0;i<n;i++)
      {
        sw[i]="sw"+io.readInt(sl,"WBNId","",i+1)+".grf";
        io.addRWGroup(sw[i]);
      }
      addAllWBNConcBenthDissChart();
      addAllWBNConcBenthTotChart();
      addAllWBNConcWaterDissChart();
      addAllWBNConcWaterTotChart();
      addWBNChart("foc Benth","WBNfocBenth","fraction");
      addWBNChart("TSS Water","WBNTSSWater","mg/L");
      for (int i=0;i<n;i++)
        io.removeGroup(sw[i]);
    }
    io.removeGroup(cp);
    io.removeGroup(sl);
    super.write(ps);
  }
}