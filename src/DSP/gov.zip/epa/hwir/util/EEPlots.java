package gov.epa.hwir.util;

import java.io.*;
import GNUPlot.Chart;
import GNUPlot.Series;

public class EEPlots extends Plots {
  String sl,ee;
  hwirio io;
  public EEPlots(String newSiteLayout) {
    sl=newSiteLayout;
    ee="ee.grf";
    io=new hwirio();
  }
  private void add3DChart(String title,String variable,String units)
  {
    Chart c=new Chart();
    boolean atLeastOne=false;
    c.setTitle(title);
    c.setLabels("year",units);
    String varny=variable+"NY";
    String varyr=variable+"YR";
    int numwbn=io.readInt(sl,"NumHab","unitless");
    for (int k=0;k<numwbn;k++)
    {
      int nrch=io.readInt(sl,"HabNumRange","unitless",k+1);
      for (int j=0;j<nrch;j++)
      {
        int n=io.readInt(ee,varny,"",k+1,j+1);
        Series x=new Series();
        Series y=new Series();
        for (int i=0;i<n;i++)
        {
          atLeastOne=true;
          x.add(io.readInt(ee,varyr,"year",k+1,j+1,i+1));
          y.add(io.readReal(ee,variable,units,k+1,j+1,i+1));
        }
        y.setLabel(variable+" ("+(k+1)+","+(j+1)+")");
        if (n>=2)
        {
          c.addSeries(y);
          c.addXSeries(x);
        }
      }
    }
    if (atLeastOne) addPlot(c);
  }
  public void write(PrintStream ps)
  {
    int n;
    setCaption("Ecological Exposure");
    io.addRWGroup(sl);
    io.addRWGroup(ee);
//Dose_rec,3,Float,0,10000000,mg/kg-day,[NumHab],[HabNumRange],[Dose_recYR]
//Dose_recNY,2,Integer,0,1000000,,[NumHab],[HabNumRange],
//Dose_recYR,3,Integer,0,1000000,Year,[NumHab],[HabNumRange],[Dose_recYR]
    add3DChart("Receptor Dose","Dose_rec","mg/kg-day");
    io.removeGroup(ee);
    io.removeGroup(sl);
    super.write(ps);
  }
}